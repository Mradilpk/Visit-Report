/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { CalendarIcon, ChevronRight, ChevronLeft, Check, Clock, FileText, MessageSquare, Paperclip } from 'lucide-react';
import { format } from 'date-fns';

import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Checkbox } from '@/components/ui/checkbox';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Calendar } from '@/components/ui/calendar';
import { cn } from '@/lib/utils';

import { Input } from '@/components/ui/input';
import { GROUPS, OFFICES, SALES_PERSONS, PERFORMANCE_CATEGORIES, PROFESSIONALISM_CATEGORIES, MOCK_HISTORY, MOCK_RATING_HISTORY, MOCK_TASKS } from './constants';
import { VisitReport, Task } from './types';

export default function App() {
  const [step, setStep] = useState(0);
  const [report, setReport] = useState<VisitReport>({
    date: new Date(),
    visitorName: '',
    office: '',
    group: '',
    salesPerson: '',
    territory: '',
    designation: '',
    performanceRatings: {},
    professionalismRatings: {},
    tasks: MOCK_TASKS as Task[],
    checklist: {
      performance: false,
      professionalism: false,
      reviewTasks: false,
      assignTask: false,
      visitorOpinion: false,
      salespersonOpinion: false,
    },
  });

  const handleSalesPersonChange = (name: string) => {
    const person = SALES_PERSONS.find((p) => p.name === name);
    if (person) {
      setReport({
        ...report,
        salesPerson: name,
        territory: person.territory,
        designation: person.designation,
      });
    }
  };

  const nextStep = () => setStep((s) => s + 1);
  const prevStep = () => setStep((s) => s - 1);

  // Step 0: Main Report Info
  const renderStep0 = () => (
    <div className="space-y-6 p-4">
      <div className="header-blue">VISIT DESERT FORT</div>
      
      <div className="space-y-4">
        <div className="flex items-center justify-between border-b pb-2">
          <Label className="font-bold">Select Date:</Label>
          <Popover>
            <PopoverTrigger asChild>
              <Button variant="outline" className={cn("w-[180px] justify-start text-left font-normal", !report.date && "text-muted-foreground")}>
                <CalendarIcon className="mr-2 h-4 w-4" />
                {report.date ? format(report.date, "PPP") : <span>Pick a date</span>}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0">
              <Calendar mode="single" selected={report.date} onSelect={(date) => date && setReport({ ...report, date })} initialFocus />
            </PopoverContent>
          </Popover>
        </div>

        <div className="space-y-2">
          <Label className="font-bold">Visitor Name (Manager)</Label>
          <Input 
            placeholder="Enter your name" 
            value={report.visitorName} 
            onChange={(e) => setReport({ ...report, visitorName: e.target.value })}
            className="bg-slate-50"
          />
        </div>

        <div className="space-y-2">
          <div className="section-header">Select Office</div>
          <Select onValueChange={(v) => setReport({ ...report, office: v })}>
            <SelectTrigger className="bg-[#E9EDF4] border-none text-center font-bold">
              <SelectValue placeholder="Select Office" />
            </SelectTrigger>
            <SelectContent>
              {OFFICES.map((o) => (
                <SelectItem key={o} value={o}>{o}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <div className="section-header">Select Group</div>
          <Select onValueChange={(v) => setReport({ ...report, group: v })}>
            <SelectTrigger className="bg-[#E9EDF4] border-none text-center font-bold">
              <SelectValue placeholder="Select Group" />
            </SelectTrigger>
            <SelectContent>
              {GROUPS.map((g) => (
                <SelectItem key={g} value={g}>{g}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <div className="section-header">Select Sales Person (Visit with)</div>
          <Select onValueChange={handleSalesPersonChange}>
            <SelectTrigger className="bg-[#E9EDF4] border-none text-center font-bold">
              <SelectValue placeholder="Select Sales Person" />
            </SelectTrigger>
            <SelectContent>
              {SALES_PERSONS.map((p) => (
                <SelectItem key={p.name} value={p.name}>{p.name}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="grid grid-cols-2 gap-4 text-sm">
          <div>
            <Label className="font-bold block mb-1">Area Visited</Label>
            <div className="p-2 bg-slate-50 border rounded">{report.territory || '-'}</div>
          </div>
          <div>
            <Label className="font-bold block mb-1">Designation</Label>
            <div className="p-2 bg-slate-50 border rounded">{report.designation || '-'}</div>
          </div>
        </div>

        <div className="space-y-2">
          <div className="section-header">Previous Performance Summary</div>
          <div className="border rounded divide-y">
            {MOCK_HISTORY.map((h, i) => (
              <div key={i} className="p-3 text-center">
                <div className="font-bold">{h.date}</div>
                <div className="text-sm text-slate-600">
                  Score {h.score} | Sales {h.sales} {h.isLatest && '(Latest)'}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <Button className="w-full bg-[#4472C4] hover:bg-[#365ba3] h-12 text-lg" onClick={nextStep}>
        Next: Quality of Performance
      </Button>
    </div>
  );

  // Generic Rating Step
  const renderRatingStep = (category: typeof PERFORMANCE_CATEGORIES[0], isProfessionalism = false) => {
    const ratings = isProfessionalism ? report.professionalismRatings : report.performanceRatings;
    const setRatings = (val: string) => {
      if (isProfessionalism) {
        setReport({ ...report, professionalismRatings: { ...report.professionalismRatings, [category.id]: val } });
      } else {
        setReport({ ...report, performanceRatings: { ...report.performanceRatings, [category.id]: val } });
      }
    };

    const nextCategory = isProfessionalism 
      ? PROFESSIONALISM_CATEGORIES[step - 18 + 1] 
      : PERFORMANCE_CATEGORIES[step];

    return (
      <div className="space-y-6 p-4">
        <div className={isProfessionalism ? "header-green" : "header-blue"}>
          {isProfessionalism ? "Quality of Professionalism" : "Quality of Performance"}
        </div>

        <div className="space-y-4">
          <div className={isProfessionalism ? "sub-section-header" : "section-header"}>
            {category.name}
          </div>
          
          <Card className="border-slate-200">
            <CardContent className="pt-6">
              <Label className="block text-center mb-4 font-medium">Choose of the below option</Label>
              <RadioGroup 
                value={ratings[category.id] as string} 
                onValueChange={setRatings}
                className="grid grid-cols-2 gap-4"
              >
                {category.options.map((opt, i) => (
                  <div key={opt} className="flex items-center space-x-2 border p-3 rounded-lg hover:bg-slate-50 cursor-pointer">
                    <RadioGroupItem value={opt} id={`${category.id}-${opt}`} />
                    <Label htmlFor={`${category.id}-${opt}`} className="cursor-pointer">{i + 1}. {opt}</Label>
                  </div>
                ))}
              </RadioGroup>
            </CardContent>
          </Card>

          <div className="space-y-2">
            <div className={isProfessionalism ? "sub-section-header" : "section-header"}>
              Previous {isProfessionalism ? 'Daily Plaining' : 'Performance'} Summary
            </div>
            <div className="border rounded divide-y">
              {MOCK_RATING_HISTORY.map((h, i) => (
                <div key={i} className="p-3 flex justify-between items-center px-8">
                  <span className="font-bold">{h.date}</span>
                  <span className="text-slate-600">{h.rating}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="flex gap-2">
          <Button variant="outline" className="flex-1 h-12" onClick={prevStep}>Back</Button>
          <Button 
            className={cn("flex-2 h-12", isProfessionalism ? "bg-[#70AD47] hover:bg-[#5a8c39]" : "bg-[#4472C4] hover:bg-[#365ba3]")} 
            onClick={nextStep}
          >
            {nextCategory ? `Next: ${nextCategory.name}` : (isProfessionalism ? 'SAVE & NEXT' : 'SAVE & NEXT')}
          </Button>
        </div>
      </div>
    );
  };

  // Step 17: Performance Checklist
  const renderPerformanceChecklist = () => (
    <div className="space-y-6 p-4">
      <div className="header-blue">VISIT DESERT FORT</div>
      
      <div className="space-y-2">
        {[
          { id: 'performance', label: 'QUALITY OF PERFORMANCE', checked: true },
          { id: 'professionalism', label: 'QUALITY OF PROFESSIONALISM', checked: false },
          { id: 'reviewTasks', label: 'Review of previous visit Tasks', checked: false },
          { id: 'assignTask', label: 'Assign Task at the End of Visit', checked: false },
          { id: 'visitorOpinion', label: 'Visitor\'s Opinion about the visit', checked: false },
          { id: 'salespersonOpinion', label: 'Salesperson\'s opinion about the visit', checked: false },
        ].map((item) => (
          <div key={item.id} className="flex items-center justify-between p-3 bg-[#E9EDF4] rounded">
            <span className="font-bold text-[#4472C4] text-sm">{item.label}</span>
            <Checkbox checked={item.checked} />
          </div>
        ))}
      </div>

      <div className="h-24 border-b border-slate-300"></div>
      <div className="h-24 border-b border-slate-300"></div>

      <Button className="w-full bg-[#4472C4] hover:bg-[#365ba3] h-12" onClick={nextStep}>
        Next: Quality of Professionalism
      </Button>
    </div>
  );

  // Step 25: Tasks Overview
  const renderTasksOverview = () => (
    <div className="space-y-6 p-4">
      <div className="header-blue">TASKS OVERVIEW</div>

      <div className="space-y-4">
        <div className="section-header">TASK STATUS</div>
        <div className="grid grid-cols-2 gap-2">
          <div className="bg-[#4472C4] text-white p-3 rounded text-center font-bold text-sm">NOT Started: 02</div>
          <div className="bg-[#4472C4] text-white p-3 rounded text-center font-bold text-sm">In Progress:</div>
        </div>
        <div className="bg-[#4472C4] text-white p-3 rounded text-center font-bold text-sm">Completed: 05</div>

        <div className="overflow-x-auto border rounded">
          <Table>
            <TableHeader className="bg-[#E9EDF4]">
              <TableRow>
                <TableHead className="text-[10px] font-bold text-[#4472C4]">TASK Detail</TableHead>
                <TableHead className="text-[10px] font-bold text-[#4472C4]">Status</TableHead>
                <TableHead className="text-[10px] font-bold text-[#4472C4]">Assign Date</TableHead>
                <TableHead className="text-[10px] font-bold text-[#4472C4]">Due Date</TableHead>
                <TableHead className="text-[10px] font-bold text-[#4472C4]">Comments</TableHead>
                <TableHead className="text-[10px] font-bold text-[#4472C4]">Attachment</TableHead>
                <TableHead className="text-[10px] font-bold text-[#4472C4]">Finished on Time</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {report.tasks.map((task) => (
                <TableRow key={task.id}>
                  <TableCell className="text-[10px]">{task.detail}</TableCell>
                  <TableCell className="text-[10px]">{task.status}</TableCell>
                  <TableCell className="text-[10px]">{task.assignDate}</TableCell>
                  <TableCell className="text-[10px]">{task.dueDate}</TableCell>
                  <TableCell className="text-[10px] text-center">{task.comments}</TableCell>
                  <TableCell className="text-[10px] text-center">{task.attachments}</TableCell>
                  <TableCell className="text-[10px] bg-[#70AD47] text-white text-center font-bold">YES</TableCell>
                </TableRow>
              ))}
              {[...Array(5)].map((_, i) => (
                <TableRow key={`empty-${i}`} className="h-8">
                  <TableCell colSpan={7}></TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </div>

      <div className="flex gap-2">
        <Button variant="outline" className="flex-1 h-12" onClick={prevStep}>Back</Button>
        <Button className="flex-2 bg-[#70AD47] hover:bg-[#5a8c39] h-12" onClick={nextStep}>
          SAVE & NEXT
        </Button>
      </div>
    </div>
  );

  // Final Checklist
  const renderFinalChecklist = () => (
    <div className="space-y-6 p-4">
      <div className="header-blue">VISIT JAIZA REPORT</div>
      
      <div className="space-y-2">
        {[
          { id: 'performance', label: 'QUALITY OF PERFORMANCE', checked: true },
          { id: 'professionalism', label: 'QUALITY OF PROFESSIONALISM', checked: true },
          { id: 'reviewTasks', label: 'Review of previous visit Tasks', checked: true },
          { id: 'assignTask', label: 'Assign Task at the End of Visit', checked: true },
          { id: 'visitorOpinion', label: 'Visitor\'s Opinion about the visit', checked: true },
          { id: 'salespersonOpinion', label: 'Salesperson\'s opinion about the visit', checked: true },
        ].map((item) => (
          <div key={item.id} className="flex items-center justify-between p-3 bg-[#E9EDF4] rounded">
            <span className="font-bold text-[#4472C4] text-sm">{item.label}</span>
            <Checkbox checked={item.checked} />
          </div>
        ))}
      </div>

      <div className="p-4 bg-green-50 border border-green-200 rounded-lg text-center">
        <div className="flex justify-center mb-2">
          <div className="bg-green-500 text-white p-2 rounded-full">
            <Check className="w-8 h-8" />
          </div>
        </div>
        <h3 className="font-bold text-green-800">Report Completed Successfully</h3>
        <p className="text-sm text-green-600">All observations and tasks have been recorded.</p>
      </div>

      <Button className="w-full bg-[#4472C4] hover:bg-[#365ba3] h-12" onClick={() => setStep(0)}>
        Start New Visit
      </Button>
    </div>
  );

  // Step 27: Review Summary
  const renderReviewSummary = () => (
    <div className="space-y-6 p-4">
      <div className="header-blue">REVIEW & SUBMIT</div>
      
      <div className="space-y-4 max-h-[60vh] overflow-y-auto pr-2">
        <div className="space-y-2">
          <h3 className="font-bold border-b pb-1">Visit Details</h3>
          <div className="grid grid-cols-2 gap-2 text-xs">
            <span className="text-slate-500">Date:</span> <span>{format(report.date, "PPP")}</span>
            <span className="text-slate-500">Visitor:</span> <span>{report.visitorName || 'N/A'}</span>
            <span className="text-slate-500">Office:</span> <span>{report.office || 'N/A'}</span>
            <span className="text-slate-500">Group:</span> <span>{report.group || 'N/A'}</span>
            <span className="text-slate-500">Visit with:</span> <span>{report.salesPerson || 'N/A'}</span>
            <span className="text-slate-500">Area:</span> <span>{report.territory || 'N/A'}</span>
          </div>
        </div>

        <div className="space-y-2">
          <h3 className="font-bold border-b pb-1">Performance Ratings</h3>
          <div className="space-y-1">
            {PERFORMANCE_CATEGORIES.map(cat => (
              <div key={cat.id} className="flex justify-between text-[10px] border-b border-slate-100 py-1">
                <span className="text-slate-600">{cat.name}</span>
                <span className="font-bold">{report.performanceRatings[cat.id] || 'Not Rated'}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="space-y-2">
          <h3 className="font-bold border-b pb-1">Professionalism Ratings</h3>
          <div className="space-y-1">
            {PROFESSIONALISM_CATEGORIES.map(cat => (
              <div key={cat.id} className="flex justify-between text-[10px] border-b border-slate-100 py-1">
                <span className="text-slate-600">{cat.name}</span>
                <span className="font-bold">{report.professionalismRatings[cat.id] || 'Not Rated'}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="flex gap-2">
        <Button variant="outline" className="flex-1 h-12" onClick={prevStep}>Back</Button>
        <Button className="flex-2 bg-[#4472C4] hover:bg-[#365ba3] h-12" onClick={nextStep}>
          SUBMIT REPORT
        </Button>
      </div>
    </div>
  );

  // Step 28: Final Report & Download
  const renderFinalReport = () => {
    const downloadReport = () => {
      const reportContent = `
VISIT DESERT FORT REPORT
-------------------------
Visitor Name: ${report.visitorName}
Date: ${format(report.date, "PPP")}
Office: ${report.office}
Group: ${report.group}
Visit with (Sales Person): ${report.salesPerson}
Area Visited: ${report.territory}
Designation: ${report.designation}

PERFORMANCE RATINGS:
${PERFORMANCE_CATEGORIES.map(cat => `- ${cat.name}: ${report.performanceRatings[cat.id] || 'N/A'}`).join('\n')}

PROFESSIONALISM RATINGS:
${PROFESSIONALISM_CATEGORIES.map(cat => `- ${cat.name}: ${report.professionalismRatings[cat.id] || 'N/A'}`).join('\n')}

TASKS:
${report.tasks.map(t => `- ${t.detail} (${t.status})`).join('\n')}
      `;
      
      const blob = new Blob([reportContent], { type: 'text/plain' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `Visit_Desert_Fort_${report.salesPerson}_${format(report.date, "yyyy-MM-dd")}.txt`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    };

    return (
      <div className="space-y-6 p-4" id="final-report">
        <div className="header-green">VISIT DESERT FORT SUMMARY</div>
        
        <div className="p-4 bg-slate-50 border rounded-lg space-y-4 text-xs">
          <div className="flex justify-between items-start border-b pb-4">
            <div>
              <h2 className="text-lg font-bold text-[#70AD47] uppercase">Visit Desert Fort</h2>
              <p className="text-slate-600 font-medium">Visitor: {report.visitorName}</p>
              <p className="text-slate-500">Visit with: {report.salesPerson}</p>
            </div>
            <div className="text-right">
              <p className="font-bold">{format(report.date, "PPP")}</p>
              <p className="text-slate-500">Office: {report.office}</p>
              <p className="text-slate-500">Area: {report.territory}</p>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-6">
            <div className="space-y-2">
              <h3 className="font-bold text-[#4472C4] border-b">Performance</h3>
              {PERFORMANCE_CATEGORIES.slice(0, 10).map(cat => (
                <div key={cat.id} className="flex justify-between border-b border-slate-100 py-1">
                  <span className="text-[9px]">{cat.name}</span>
                  <span className="font-bold">{report.performanceRatings[cat.id] || '-'}</span>
                </div>
              ))}
            </div>
            <div className="space-y-2">
              <h3 className="font-bold text-[#4472C4] border-b">Professionalism</h3>
              {PROFESSIONALISM_CATEGORIES.map(cat => (
                <div key={cat.id} className="flex justify-between border-b border-slate-100 py-1">
                  <span className="text-[9px]">{cat.name}</span>
                  <span className="font-bold">{report.professionalismRatings[cat.id] || '-'}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="space-y-2">
            <h3 className="font-bold text-[#4472C4] border-b">Active Tasks</h3>
            {report.tasks.map(task => (
              <div key={task.id} className="flex justify-between items-center bg-white p-2 rounded border">
                <span className="text-[10px]">{task.detail}</span>
                <span className="bg-green-100 text-green-700 px-2 py-0.5 rounded text-[9px] font-bold">{task.status}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="flex gap-2 no-print">
          <Button className="flex-1 bg-[#4472C4] hover:bg-[#365ba3] h-12" onClick={downloadReport}>
            Download Report (.txt)
          </Button>
          <Button className="flex-1 bg-[#70AD47] hover:bg-[#5a8c39] h-12" onClick={() => window.print()}>
            Print / Save PDF
          </Button>
        </div>

        <Button variant="ghost" className="w-full no-print" onClick={() => setStep(0)}>
          Start New Visit
        </Button>
      </div>
    );
  };

  const renderCurrentStep = () => {
    if (step === 0) return renderStep0();
    
    // Performance Categories (Steps 1-16)
    if (step >= 1 && step <= 16) {
      return renderRatingStep(PERFORMANCE_CATEGORIES[step - 1]);
    }

    // Performance Checklist (Step 17)
    if (step === 17) return renderPerformanceChecklist();

    // Professionalism Categories (Steps 18-25)
    if (step >= 18 && step <= 25) {
      return renderRatingStep(PROFESSIONALISM_CATEGORIES[step - 18], true);
    }

    // Tasks Overview (Step 26)
    if (step === 26) return renderTasksOverview();

    // Review Summary (Step 27)
    if (step === 27) return renderReviewSummary();

    // Final Report (Step 28)
    if (step === 28) return renderFinalReport();

    return null;
  };

  return (
    <div className="min-h-screen bg-slate-100 py-8 px-4">
      <div className="visit-report-container overflow-hidden">
        <AnimatePresence mode="wait">
          <motion.div
            key={step}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.2 }}
          >
            {renderCurrentStep()}
          </motion.div>
        </AnimatePresence>
      </div>
    </div>
  );
}
