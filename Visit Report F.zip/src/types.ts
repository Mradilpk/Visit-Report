export type Rating = 'Best' | 'Good' | 'AVG' | 'Below AVG';

export interface PerformanceRecord {
  date: string;
  score: string;
  sales: string;
  isLatest?: boolean;
}

export interface CategoryRating {
  id: string;
  name: string;
  rating: Rating | string;
  history: { date: string; rating: string }[];
}

export interface Task {
  id: string;
  detail: string;
  status: 'Complete' | 'In Progress' | 'Not Started';
  assignDate: string;
  dueDate: string;
  comments: number;
  attachments: number;
  finishedOnTime: boolean;
}

export interface VisitReport {
  date: Date;
  visitorName: string;
  office: string;
  group: string;
  salesPerson: string;
  territory: string;
  designation: string;
  performanceRatings: Record<string, Rating | string>;
  professionalismRatings: Record<string, Rating | string>;
  tasks: Task[];
  checklist: Record<string, boolean>;
}
