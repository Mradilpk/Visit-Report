import { Rating } from './types';

export const GROUPS = ['AGILE', 'STRIVE', 'ELITE', 'PRIME'];

export const OFFICES = ['Head Office', 'Regional Office North', 'Regional Office South', 'Branch Office East'];

export const SALES_PERSONS = [
  { name: 'Ali Sheikh', territory: 'Rawalpindi', designation: 'Area Sales Manager' },
  { name: 'Usman Khan', territory: 'Islamabad', designation: 'Sales Executive' },
  { name: 'Zeeshan Ahmed', territory: 'Lahore', designation: 'Regional Manager' },
];

export const PERFORMANCE_CATEGORIES = [
  { id: 'daily_planning', name: 'DAILY PLANNING', options: ['Best', 'Good', 'AVG', 'Below AVG'] },
  { id: 'product_knowledge', name: 'PRODUCT KNOWLEDGE', options: ['Best', 'Good', 'AVG', 'Below AVG'] },
  { id: 'prospecting', name: 'PROSPECTING', options: ['Best', 'Good', 'AVG', 'Below AVG'] },
  { id: 'resolving_complaints', name: 'RESOLVING COMPLAINTS SKILL', options: ['Best', 'Good', 'AVG', 'Below AVG'] },
  { id: 'customer_relation', name: 'CUSTOMER RELATION', options: ['Best', 'Good', 'AVG', 'Below AVG'] },
  { id: 'farm_level_work', name: 'QUALITY OF FARM LEVEL WORK', options: ['Best', 'Good', 'AVG', 'Below AVG'] },
  { id: 'other_segments_work', name: 'QUALITY OF OTHER SEGMENTS WORK', options: ['Best', 'Good', 'AVG', 'Below AVG'] },
  { id: 'promotion_material', name: 'PROMOTION MATERIAL USES', options: ['Best', 'Good', 'AVG', 'Below AVG'] },
  { id: 'getting_work_dist', name: 'SKILL OF GETTING WORK FROM DISTRIBUTOR', options: ['Best', 'Good', 'AVG', 'Below AVG'] },
  { id: 'bag_setting', name: 'BAG SETTING', options: ['Best', 'Good', 'AVG', 'Below AVG'] },
  { id: 'market_info', name: 'MARKET INFORMATION', options: ['Best', 'Good', 'AVG', 'Below AVG'] },
  { id: 'productivity', name: 'PRODUCTIVITY', options: ['Best', 'Good', 'AVG', 'Below AVG'] },
  { id: 'punctuality', name: 'PUNCTUALITY', options: ['Best', 'Good', 'AVG', 'Below AVG'] },
  { id: 'sales_expectation', name: 'SALES EXPECTATION VS ACH', options: ['100 %', '70 %', '50 %', 'Below 50 %'] },
  { id: 'care_of_vehicle', name: 'CARE OF VEHICLE', options: ['Best', 'Good', 'AVG', 'Below AVG'] },
  { id: 'route_plan', name: 'ROUTE PLAN', options: ['Best', 'Good', 'AVG', 'Below AVG'] },
];

export const PROFESSIONALISM_CATEGORIES = [
  { id: 'ask_questions', name: 'How to ask Questions', options: ['Best', 'Good', 'AVG', 'Below AVG'] },
  { id: 'customer_info', name: 'CUSTOMER INFORMATION', options: ['Best', 'Good', 'AVG', 'Below AVG'] },
  { id: 'prep_before_calling', name: 'PREPARATION BEFORE CALLING', options: ['Best', 'Good', 'AVG', 'Below AVG'] },
  { id: 'initial_sales_call', name: 'INITIAL SALES CALL GETTING ATTENTION', options: ['Best', 'Good', 'AVG', 'Below AVG'] },
  { id: 'identifying_needs', name: 'IDENTIFYING CUSTOMER NEEDS', options: ['Best', 'Good', 'AVG', 'Below AVG'] },
  { id: 'response_handling', name: 'RESPONSE HANDLING', options: ['Best', 'Good', 'AVG', 'Below AVG'] },
  { id: 'product_diff', name: 'PRODUCT DIFFERENTIATION', options: ['Best', 'Good', 'AVG', 'Below AVG'] },
  { id: 'commitment_for_order', name: 'GETTING COMMITMENT FOR ORDER', options: ['Best', 'Good', 'AVG', 'Below AVG'] },
];

export const MOCK_HISTORY = [
  { date: '15-Jan-26', score: '75%', sales: '1.2M', isLatest: true },
  { date: '10-Jan-26', score: '80%', sales: '1.1M' },
  { date: '5-Jan-26', score: '70%', sales: '0.9M' },
  { date: '28-Dec-25', score: '85%', sales: '1.3M' },
];

export const MOCK_RATING_HISTORY = [
  { date: '15-Jan-26', rating: 'Good' },
  { date: '10-Jan-26', rating: 'Good' },
  { date: '5-Jan-26', rating: 'AVG' },
  { date: '28-Dec-25', rating: 'AVG' },
];

export const MOCK_TASKS = [
  {
    id: '1',
    detail: 'FRA Product Audio Message',
    status: 'Complete',
    assignDate: '20-Jan-26',
    dueDate: '31-Jan-26',
    comments: 7,
    attachments: 2,
    finishedOnTime: true,
  },
];
